import 'package:flutter/material.dart';
import 'package:muevete/features/training/domain/entities/workout_exercise.dart';
import 'package:muevete/features/training/presentation/widgets/panel/exercise_tile.dart';

class ExerciseList extends StatelessWidget {
  const ExerciseList({
    super.key,
    required this.exercises,
    required this.scrollController,
  });

  final List<WorkoutExercise> exercises;

  final ScrollController scrollController;


  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      controller: scrollController,

      padding: const EdgeInsets.only(
        left: 24,
        right: 24,
        bottom: 24
      ),

      itemCount: exercises.length,

      itemBuilder: (_, index) {
        return ExerciseTile(
          exercise: exercises[index]
        );
      },
    );
  }
}