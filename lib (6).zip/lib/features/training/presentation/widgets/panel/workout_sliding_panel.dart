import 'package:flutter/material.dart';
import 'package:muevete/features/training/domain/entities/workout.dart';
import 'package:muevete/features/training/presentation/widgets/panel/exercise_section.dart';
import 'package:muevete/features/training/presentation/widgets/panel/workout_overview.dart';
import 'package:muevete/shared/theme/app_colors.dart';

class WorkoutSlidingPanel extends StatelessWidget {
  final Workout workout;

  const WorkoutSlidingPanel({
    super.key,
    required this.workout,
  });

  @override
  Widget build(BuildContext context) {
    final screenHeight = MediaQuery.sizeOf(context).height * 0.68;

    return DraggableScrollableSheet(
      initialChildSize: .62,
      minChildSize: .62,
      maxChildSize: .92,
      builder: (context, scrollController) {
        return Align(
          alignment: Alignment.bottomCenter,
          child: Container(
        
            height: screenHeight,
        
            width: double.infinity,
        
            decoration: BoxDecoration(
              color: AppColors.softGrey,
              borderRadius: BorderRadius.vertical(
                top: Radius.circular(32),
              ),
            ),
        
            child: Column(
              children: [
                _DragHandle(),
        
                WorkoutOverview(workout: workout,),
        
                const Divider(height: 1,),
        
                Expanded(
                  child: ExerciseSection(
                    exercises: workout.exercises,
                   scrollController: scrollController,
                  ),
                ),
              ],
            ),
          ),
        );
      },
      
    );
  }
}

class _DragHandle extends StatelessWidget {
  const _DragHandle();

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Center(
        child: Container(
          width: 40,
          height: 4,
          decoration: BoxDecoration(
            color: Colors.grey.shade400,
            borderRadius: BorderRadius.circular(999)
          ),
        ),
      ),
    );
  }
}