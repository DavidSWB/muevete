class UserTraining {

  final String activePlanId;

  final DateTime planStartDate;

  const UserTraining({

    required this.activePlanId,

    required this.planStartDate,

  });

  factory UserTraining.fromJson(
      Map<String,dynamic> json){

    return UserTraining(

      activePlanId:
          json["activePlanId"],

      planStartDate:
          DateTime.parse(
            json["planStartDate"],
          ),

    );

  }

  Map<String,dynamic> toJson(){

    return{

      "activePlanId":activePlanId,

      "planStartDate":
          planStartDate.toIso8601String(),

    };

  }

  UserTraining copyWith({

    String? activePlanId,

    DateTime? planStartDate,

  }){

    return UserTraining(

      activePlanId:
          activePlanId ??
          this.activePlanId,

      planStartDate:
          planStartDate ??
          this.planStartDate,

    );

  }

}