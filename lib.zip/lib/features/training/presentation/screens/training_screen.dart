import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:muevete/features/training/presentation/providers/training_provider.dart';

class TrainingScreen extends ConsumerWidget {
  const TrainingScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final training = ref.watch(trainingRepositoryProvider);

    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,

          children: [
            Text("Training"),
            ElevatedButton(
              onPressed: (){
                context.push("/");
              }, 
              child: const Text('(Home)'),
            ),
            ElevatedButton(
              onPressed: (){
                context.push("/");
              }, 
              child: const Text('Training preferences'),
            ),
            training.when(
              data: (d){
                return Column(
                  children: [
                    Text("Training Plan", style: TextStyle(fontWeight: FontWeight.bold)),
                    Text("Plan: ${d.template[0].name}"),
                    Text("Days per Week: ${d.daysPerWeek}"),
                  ],
                );
              }, 
              error: (err, stack) => Text('Error: $err'), 
              loading: ()=> CircularProgressIndicator(),
            ),
          ],
        ),
      ),
    );
  }
}