import 'package:muevete/shared/entities/progresssummary.dart';
import 'package:muevete/features/profile/domain/entities/userstats.dart';
import 'package:muevete/features/profile/domain/entities/usertraining.dart';

class UserModel {
  final String id;
  final String email;
  final String username;

  final String? sex;
  final int? age;
  final double? height;
  final double? weight;
  final DateTime? createdAt;

  final List<String>? medicalConditions;

  final UserStats? stats;
  final UserTraining? training;
  final ProgressSummary? progressSummary;

  final List<DateTime> completedWorkouts;

  const UserModel({
    required this.id,
    required this.email,
    required this.username,
    this.sex,
    this.age,
    this.height,
    this.weight,
    this.createdAt,
    this.medicalConditions,
    this.stats,
    this.training,
    this.progressSummary,
    this.completedWorkouts = const [],
  });

  factory UserModel.fromJson(Map<String, dynamic> json) {
    return UserModel(
      id: json["id"],
      email: json["email"],
      username: json["username"],
      sex: json["sex"],
      age: (json["age"] as num?)?.toInt(),
      height: (json["height"] as num?)?.toDouble(),
      weight: (json["weight"] as num?)?.toDouble(),

      createdAt: json["createdAt"] == null
          ? null
          : DateTime.parse(json["createdAt"]),

      medicalConditions:
          (json["medicalConditions"] as List<dynamic>?)
              ?.map((e) => e.toString())
              .toList(),

      stats: UserStats.fromJson(json["stats"]),

      training: UserTraining.fromJson(json["training"]),

      progressSummary:
          ProgressSummary.fromJson(json["progressSummary"]),

      completedWorkouts:
          (json["completedWorkouts"] as List<dynamic>? ?? [])
              .map((e) => DateTime.parse(e))
              .toList(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      "id": id,
      "email": email,
      "username": username,
      "sex": sex,
      "age": age,
      "height": height,
      "weight": weight,
      "createdAt": createdAt?.toIso8601String(),
      "medicalConditions": medicalConditions,
      "stats": stats!.toJson(),
      "training": training!.toJson(),
      "progressSummary": progressSummary!.toJson(),
      "completedWorkouts":
          completedWorkouts.map((e) => e.toIso8601String()).toList(),
    };
  }
}