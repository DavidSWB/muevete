import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:muevete/features/profile/domain/entities/user_model.dart';
import 'package:muevete/features/profile/domain/repositories/profile_repository.dart';

class FirestoreProfileRepository implements ProfileRepository{

  FirestoreProfileRepository({
    required FirebaseFirestore firestore,  
    required FirebaseAuth auth,

  }): _auth = auth,
  _firestore = firestore;

  final FirebaseAuth _auth;
  final FirebaseFirestore _firestore;

  @override
  Future<UserModel> getProfile() async{

    final snapshot = await _firestore
                      .collection('users')
                      .doc(_auth.currentUser!.uid)
                      .get();
    
    final data = snapshot.data();
    final userData = UserModel.fromJson(data!);
    return UserModel(
      id: _auth.currentUser!.uid,
      email: userData.email, 
      username: userData.username,
      age: userData.age,
      height: userData.height,
      weight: userData.weight,
      sex: userData.sex,
      medicalConditions: userData.medicalConditions,
      training: userData.training,
      stats: userData.stats,
      completedWorkouts: userData.completedWorkouts,
      progressSummary: userData.progressSummary,
      createdAt: userData.createdAt,
    );
  }

  @override
  Future<void> saveProfile(UserModel user) async{
    await _firestore
      .collection('users')
      .add(user.toJson());
  }
}