import 'package:muevete/features/profile/domain/entities/user_model.dart';
import 'package:riverpod_annotation/riverpod_annotation.dart';

part 'profle_provider.g.dart';

@riverpod
class ProfileProvider extends _$ProfileProvider{

  @override
  Future<UserModel> build() async{
    // final profileRepository = ref.red();
    // final userData = await profileRepository.getProfile();


    return UserModel.fromJson(userData);
  }

  void updateInfo(){}
  void updateStats(){}

}