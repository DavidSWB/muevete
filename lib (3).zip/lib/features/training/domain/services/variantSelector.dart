import 'package:muevete/features/training/domain/entities/exercise.dart';
import 'package:muevete/features/training/domain/entities/exercise_level.dart';
import 'package:muevete/features/training/domain/entities/exercise_variant.dart';
import 'package:muevete/features/profile/domain/entities/userstats.dart';

class Variantselector {

  double getLowestTargetStat(
    Exercise exercise,
    UserStats stats,
  ) {

    double minStat = 5;

    for(final target in exercise.targets ){

      final currentStat = stats.getStat(target);

      if(currentStat < minStat){
        minStat = currentStat;
      }

    }

    return minStat;

  }
  ExerciseLevel calculateLevel(double stat){

      if(stat > 4){
          return ExerciseLevel.advanced;
      }

      if(stat > 2){
          return ExerciseLevel.intermediate;
      }

      return ExerciseLevel.beginner;

  }
  ExerciseVariant findVariant(
      Exercise exercise,
      ExerciseLevel level,
  ){

      return exercise.variants.firstWhere(

          (variant) => variant.requiredLevel == level,

      );

  }
}