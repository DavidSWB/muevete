class UserTraining {

  final String activePlanId;
  final int currentWeek;
  final DateTime? planStartDate;

  const UserTraining({
    required this.activePlanId,
    required this.currentWeek,
    this.planStartDate,
  });

  factory UserTraining.fromJson(Map<String, dynamic> json){

    return UserTraining(
      activePlanId: json["activePlanId"],
      currentWeek: json["currentWeek"] ?? 1,
      planStartDate: json["planStartDate"] == null
          ? null
          : DateTime.parse(json["planStartDate"]),
    );
  }

  Map<String, dynamic> toJson(){

    return {
      "activePlanId": activePlanId,
      "currentWeek": currentWeek,
      "planStartDate": planStartDate?.toIso8601String(),
    };
  }

}