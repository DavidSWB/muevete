import 'dart:async';

import 'package:muevete/features/training/domain/entities/workout.dart';
import 'package:muevete/features/training/presentation/providers/workout_builder_provider.dart';
import 'package:muevete/shared/entities/userstats.dart';
import 'package:riverpod_annotation/riverpod_annotation.dart';

part 'workout_controller.g.dart';

@riverpod
class WorkoutController 
  extends _$WorkoutController{

    @override
    FutureOr<Workout?> build(){
      return null;
    }

    Future<void> loadWorkout({
      required String planId,
      required int week,
      required int day,
      required UserStats stats,
    }) async{
  
    state = const AsyncLoading();

    final builder = ref.read(workoutBuilderProvider);

    state = await AsyncValue.guard(() async{

      return builder.buildWorkout(

        planId: planId,

        week: week,

        day: day,

        stats: stats,

      );
    });

  }
}