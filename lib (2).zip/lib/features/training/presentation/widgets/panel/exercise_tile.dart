import 'package:flutter/material.dart';
import 'package:muevete/features/training/domain/entities/workout_exercise.dart';

class ExerciseTile extends StatelessWidget {
  const ExerciseTile({
    super.key,
    required this.exercise,
  });

  final WorkoutExercise exercise;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.fromLTRB(24, 0, 24, 16),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.grey.shade100,
        borderRadius: BorderRadius.circular(16)
      ),
      child: Row(
        children: [
          _Thumbnail(),

          const SizedBox(width: 16),

          _ExerciseInfo(exercise: exercise),

        const SizedBox(width: 16),


          _Chevron(),
        ],
      ),
    );
  }
}

class _Thumbnail extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 64,
      height: 64,
      decoration: BoxDecoration(
        color: Colors.grey.shade300,
        borderRadius: BorderRadius.circular(12)
      ),
    );
  }
}

class _ExerciseInfo extends StatelessWidget {
  const _ExerciseInfo({
    required this.exercise,
  });

  final WorkoutExercise exercise;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          exercise.exercise.name['en'] ?? 'Exercise name',
          style: Theme.of(context).textTheme.titleMedium,
        ),

        const SizedBox(width: 4),

        Text(
          '${exercise.reps} reps',
          style: Theme.of(context).textTheme.bodySmall,
        ),


        Divider(
          height: 2,
        ),
      ],
    );
  }
}

class _Chevron extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
   return const Icon(Icons.chevron_right);
  }
}