import 'package:flutter/material.dart';
import 'package:muevete/features/training/domain/entities/workout_exercise.dart';
import 'package:muevete/features/training/presentation/widgets/panel/exercise_list.dart';

class ExerciseSection extends StatelessWidget {
  const ExerciseSection({
    super.key,
    required this.exercises,
  });

  final List<WorkoutExercise> exercises;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(24, 20, 24, 12),
          child: Row(
            children: [
              Text(
                'Exercises',
                style: Theme.of(context).textTheme.titleMedium,
              ),
            ],
          ),
        ),
        Expanded(
          child: ExerciseList(
            exercises: exercises,
          ),
        ),
      ],
    );
  }
}