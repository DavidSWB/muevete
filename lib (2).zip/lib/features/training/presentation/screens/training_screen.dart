import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:muevete/features/training/domain/entities/workout.dart';
import 'package:muevete/features/training/presentation/providers/workout_builder_provider.dart';
import 'package:muevete/features/training/presentation/providers/workout_controller.dart';
import 'package:muevete/features/training/presentation/widgets/hero/workout_hero.dart';
import 'package:muevete/features/training/presentation/widgets/panel/workout_sliding_panel.dart';

class TrainingScreen extends ConsumerWidget {
  const TrainingScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) async {
    final workoutProvider = await ref.watch(workoutControllerProvider.notifier);
    final user = await ref.watch(userProvider);

    return Scaffold(
      body: Center(
        child: Stack(
          children: [   
            WorkoutSlidingPanel(
              workout: workoutProvider.loadWorkout(
                planId: user.PlanId, 
                week: 1, 
                day: 1, 
                stats: user.stats,
              ),
            ),
            WorkoutHero(),
          ],
        ),
      ),
    );
  }
}