import 'package:muevete/features/training/domain/entities/workout.dart';
import 'package:muevete/features/training/domain/entities/workout_exercise.dart';
import 'package:muevete/features/training/domain/repositories/exercise_repository.dart';
import 'package:muevete/features/training/domain/repositories/progression_repository.dart';
import 'package:muevete/features/training/domain/repositories/training_repository.dart';
import 'package:muevete/features/training/domain/services/variantSelector.dart';
import 'package:muevete/shared/entities/userstats.dart';

class WorkoutBuilder {
  final TrainingRepository trainingRepository;
  final ExerciseRepository exerciseRepository; 
  final ProgressionRepository progressionRepository; 
  final Variantselector variantSelector; 

  const WorkoutBuilder ({
    required this.trainingRepository,

    required this.exerciseRepository,

    required this.progressionRepository,

    required this.variantSelector,
  });
  
  Future<Workout> buildWorkout({

    required String planId,
    required int day,
    required int week,
    required UserStats stats,

  }) async {

    final plan = await trainingRepository.getPlan(planId);
    final planName = plan.name;
    

    final planDay = plan.template.firstWhere(
        (e) => e.day == day,
    );

    final exercises = <WorkoutExercise>[];

    for(final reference in planDay.exercises){

        final exercise =
            await exerciseRepository.getExercise(
                reference.exerciseId,
            );

        final lowestStat =
            variantSelector.getLowestTargetStat(
                exercise,
                stats,
            );

        final level =
            variantSelector.calculateLevel(lowestStat);

        final variant =
            variantSelector.findVariant(
                exercise,
                level,
            );

        final progression =
            await progressionRepository.getRules(
                exercise.type,
                level,
            );
        final cycle = 
            progression.cycle.firstWhere(
              (c) => c.week == week,
              orElse: ()=>progression.cycle.last,
            );

        exercises.add(

            WorkoutExercise(

                exercise: variant,

                sets: cycle.sets,

                rest: cycle.rest ?? 90,

                reps: cycle.reps,

            ),

        );

    }

    return Workout(

        name: planName,

        day: day,

        exercises: exercises,

    );

  }
}