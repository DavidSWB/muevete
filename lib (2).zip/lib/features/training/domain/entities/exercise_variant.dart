import 'package:muevete/features/training/domain/entities/exercise_level.dart';

class ExerciseVariant {

  final String variantId;

  final String exerciseId;

  final Map<String,String> name;

  final Map<String,String> description;

  final String difficulty;

  final String visualPath;

  final ExerciseLevel requiredLevel;

  const ExerciseVariant({

    required this.variantId,

    required this.exerciseId,

    required this.name,

    required this.description,

    required this.difficulty,

    required this.visualPath,

    required this.requiredLevel,

  });

  factory ExerciseVariant.fromJson(
      Map<String,dynamic> json,
  ){

    return ExerciseVariant(

      variantId: json["variantId"],

      exerciseId: json["exerciseId"],

      name:
          Map<String,String>.from(
            json["name"],
          ),

      description:
          Map<String,String>.from(
            json["description"],
          ),

      difficulty: json["difficulty"],

      visualPath: json["visualPath"],

      requiredLevel:
          ExerciseLevel.values.firstWhere(
            (e)=> e.name == json["requiredLevel"],
          ),

    );

  }

  Map<String,dynamic> toJson(){

    return {

      "variantId": variantId,

      "exerciseId": exerciseId,

      "name": name,

      "description": description,

      "difficulty": difficulty,

      "visualPath": visualPath,

      "requiredLevel": requiredLevel.name,

    };

  }

}