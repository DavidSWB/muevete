import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:muevete/features/training/presentation/providers/workout_controller.dart';
import 'package:muevete/features/training/presentation/widgets/hero/workout_hero.dart';
import 'package:muevete/features/training/presentation/widgets/panel/workout_sliding_panel.dart';
import 'package:muevete/shared/screens/error_screen.dart';
import 'package:muevete/shared/screens/loading_screen.dart';

class TrainingScreen extends ConsumerWidget {

  const TrainingScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {

    final workout =
        ref.watch(workoutControllerProvider);

    return workout.when(

      loading: () =>
          const LoadingScreen(),

      error: (error, stack) =>
          ErrorScreen(error.toString()),

      data: (workout) {

        return Scaffold(

          body: Stack(

            children: [

              WorkoutSlidingPanel(

                workout: workout!,

              ),

              const WorkoutHero(),

            ],

          ),

        );

      },

    );

  }

}